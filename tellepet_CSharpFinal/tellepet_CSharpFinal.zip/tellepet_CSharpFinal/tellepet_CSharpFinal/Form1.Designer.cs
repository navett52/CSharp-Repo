﻿namespace tellepet_CSharpFinal
{
    partial class EvNav
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.btnState = new System.Windows.Forms.Button();
            this.pnlHome = new System.Windows.Forms.Panel();
            this.txtStreetNum = new System.Windows.Forms.TextBox();
            this.btnStreetNum = new System.Windows.Forms.Button();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.btnStreet = new System.Windows.Forms.Button();
            this.btnCity = new System.Windows.Forms.Button();
            this.txtState = new System.Windows.Forms.TextBox();
            this.pnlKeyboard = new System.Windows.Forms.Panel();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.lstResults = new System.Windows.Forms.ListBox();
            this.txtEntered = new System.Windows.Forms.TextBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnShift = new System.Windows.Forms.Button();
            this.btnBackspace = new System.Windows.Forms.Button();
            this.btnSpace = new System.Windows.Forms.Button();
            this.btnT = new System.Windows.Forms.Button();
            this.btnS = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnQ = new System.Windows.Forms.Button();
            this.btnP = new System.Windows.Forms.Button();
            this.btnO = new System.Windows.Forms.Button();
            this.btnN = new System.Windows.Forms.Button();
            this.btnM = new System.Windows.Forms.Button();
            this.btnL = new System.Windows.Forms.Button();
            this.btnK = new System.Windows.Forms.Button();
            this.btnZ = new System.Windows.Forms.Button();
            this.btnY = new System.Windows.Forms.Button();
            this.btnX = new System.Windows.Forms.Button();
            this.btnW = new System.Windows.Forms.Button();
            this.btnV = new System.Windows.Forms.Button();
            this.btnU = new System.Windows.Forms.Button();
            this.btnJ = new System.Windows.Forms.Button();
            this.btnI = new System.Windows.Forms.Button();
            this.btnH = new System.Windows.Forms.Button();
            this.btnG = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.btnD = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnA = new System.Windows.Forms.Button();
            this.pnlHome.SuspendLayout();
            this.pnlKeyboard.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAddress
            // 
            this.txtAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAddress.Enabled = false;
            this.txtAddress.Location = new System.Drawing.Point(14, 14);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(345, 20);
            this.txtAddress.TabIndex = 0;
            // 
            // btnState
            // 
            this.btnState.Location = new System.Drawing.Point(14, 40);
            this.btnState.Name = "btnState";
            this.btnState.Size = new System.Drawing.Size(75, 23);
            this.btnState.TabIndex = 1;
            this.btnState.Text = "State";
            this.btnState.UseVisualStyleBackColor = true;
            this.btnState.Click += new System.EventHandler(this.btnState_Click);
            // 
            // pnlHome
            // 
            this.pnlHome.Controls.Add(this.txtStreetNum);
            this.pnlHome.Controls.Add(this.btnStreetNum);
            this.pnlHome.Controls.Add(this.txtStreet);
            this.pnlHome.Controls.Add(this.txtCity);
            this.pnlHome.Controls.Add(this.btnStreet);
            this.pnlHome.Controls.Add(this.btnCity);
            this.pnlHome.Controls.Add(this.txtState);
            this.pnlHome.Controls.Add(this.txtAddress);
            this.pnlHome.Controls.Add(this.btnState);
            this.pnlHome.Location = new System.Drawing.Point(2, 2);
            this.pnlHome.Name = "pnlHome";
            this.pnlHome.Size = new System.Drawing.Size(374, 152);
            this.pnlHome.TabIndex = 2;
            // 
            // txtStreetNum
            // 
            this.txtStreetNum.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtStreetNum.Enabled = false;
            this.txtStreetNum.Location = new System.Drawing.Point(94, 120);
            this.txtStreetNum.Name = "txtStreetNum";
            this.txtStreetNum.Size = new System.Drawing.Size(265, 20);
            this.txtStreetNum.TabIndex = 8;
            // 
            // btnStreetNum
            // 
            this.btnStreetNum.Location = new System.Drawing.Point(14, 117);
            this.btnStreetNum.Name = "btnStreetNum";
            this.btnStreetNum.Size = new System.Drawing.Size(75, 23);
            this.btnStreetNum.TabIndex = 7;
            this.btnStreetNum.Text = "Street #";
            this.btnStreetNum.UseVisualStyleBackColor = true;
            this.btnStreetNum.Click += new System.EventHandler(this.btnStreetNum_Click);
            // 
            // txtStreet
            // 
            this.txtStreet.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtStreet.Enabled = false;
            this.txtStreet.Location = new System.Drawing.Point(94, 94);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(265, 20);
            this.txtStreet.TabIndex = 6;
            this.txtStreet.TextChanged += new System.EventHandler(this.txtStreet_TextChanged);
            // 
            // txtCity
            // 
            this.txtCity.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCity.Enabled = false;
            this.txtCity.Location = new System.Drawing.Point(94, 68);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(265, 20);
            this.txtCity.TabIndex = 5;
            this.txtCity.TextChanged += new System.EventHandler(this.txtCity_TextChanged);
            // 
            // btnStreet
            // 
            this.btnStreet.Location = new System.Drawing.Point(14, 91);
            this.btnStreet.Name = "btnStreet";
            this.btnStreet.Size = new System.Drawing.Size(75, 23);
            this.btnStreet.TabIndex = 4;
            this.btnStreet.Text = "Street";
            this.btnStreet.UseVisualStyleBackColor = true;
            this.btnStreet.Click += new System.EventHandler(this.btnStreet_Click);
            // 
            // btnCity
            // 
            this.btnCity.Location = new System.Drawing.Point(14, 65);
            this.btnCity.Name = "btnCity";
            this.btnCity.Size = new System.Drawing.Size(75, 23);
            this.btnCity.TabIndex = 3;
            this.btnCity.Text = "City";
            this.btnCity.UseVisualStyleBackColor = true;
            this.btnCity.Click += new System.EventHandler(this.btnCity_Click);
            // 
            // txtState
            // 
            this.txtState.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtState.Enabled = false;
            this.txtState.Location = new System.Drawing.Point(94, 41);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(265, 20);
            this.txtState.TabIndex = 2;
            this.txtState.TextChanged += new System.EventHandler(this.txtState_TextChanged);
            // 
            // pnlKeyboard
            // 
            this.pnlKeyboard.Controls.Add(this.btn0);
            this.pnlKeyboard.Controls.Add(this.btn9);
            this.pnlKeyboard.Controls.Add(this.btn8);
            this.pnlKeyboard.Controls.Add(this.btn7);
            this.pnlKeyboard.Controls.Add(this.btn6);
            this.pnlKeyboard.Controls.Add(this.btn5);
            this.pnlKeyboard.Controls.Add(this.btn4);
            this.pnlKeyboard.Controls.Add(this.btn3);
            this.pnlKeyboard.Controls.Add(this.btn2);
            this.pnlKeyboard.Controls.Add(this.btn1);
            this.pnlKeyboard.Controls.Add(this.lstResults);
            this.pnlKeyboard.Controls.Add(this.txtEntered);
            this.pnlKeyboard.Controls.Add(this.btnEnter);
            this.pnlKeyboard.Controls.Add(this.btnShift);
            this.pnlKeyboard.Controls.Add(this.btnBackspace);
            this.pnlKeyboard.Controls.Add(this.btnSpace);
            this.pnlKeyboard.Controls.Add(this.btnT);
            this.pnlKeyboard.Controls.Add(this.btnS);
            this.pnlKeyboard.Controls.Add(this.btnR);
            this.pnlKeyboard.Controls.Add(this.btnQ);
            this.pnlKeyboard.Controls.Add(this.btnP);
            this.pnlKeyboard.Controls.Add(this.btnO);
            this.pnlKeyboard.Controls.Add(this.btnN);
            this.pnlKeyboard.Controls.Add(this.btnM);
            this.pnlKeyboard.Controls.Add(this.btnL);
            this.pnlKeyboard.Controls.Add(this.btnK);
            this.pnlKeyboard.Controls.Add(this.btnZ);
            this.pnlKeyboard.Controls.Add(this.btnY);
            this.pnlKeyboard.Controls.Add(this.btnX);
            this.pnlKeyboard.Controls.Add(this.btnW);
            this.pnlKeyboard.Controls.Add(this.btnV);
            this.pnlKeyboard.Controls.Add(this.btnU);
            this.pnlKeyboard.Controls.Add(this.btnJ);
            this.pnlKeyboard.Controls.Add(this.btnI);
            this.pnlKeyboard.Controls.Add(this.btnH);
            this.pnlKeyboard.Controls.Add(this.btnG);
            this.pnlKeyboard.Controls.Add(this.btnF);
            this.pnlKeyboard.Controls.Add(this.btnE);
            this.pnlKeyboard.Controls.Add(this.btnD);
            this.pnlKeyboard.Controls.Add(this.btnC);
            this.pnlKeyboard.Controls.Add(this.btnB);
            this.pnlKeyboard.Controls.Add(this.btnA);
            this.pnlKeyboard.Location = new System.Drawing.Point(2, 2);
            this.pnlKeyboard.Name = "pnlKeyboard";
            this.pnlKeyboard.Size = new System.Drawing.Size(722, 426);
            this.pnlKeyboard.TabIndex = 7;
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(517, 196);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(50, 50);
            this.btn0.TabIndex = 59;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(461, 196);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(50, 50);
            this.btn9.TabIndex = 58;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(405, 196);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(50, 50);
            this.btn8.TabIndex = 57;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(349, 196);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(50, 50);
            this.btn7.TabIndex = 56;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(294, 196);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(50, 50);
            this.btn6.TabIndex = 55;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(238, 196);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(50, 50);
            this.btn5.TabIndex = 54;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(182, 196);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(50, 50);
            this.btn4.TabIndex = 53;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(126, 196);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(50, 50);
            this.btn3.TabIndex = 52;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(70, 196);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(50, 50);
            this.btn2.TabIndex = 51;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(14, 196);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(50, 50);
            this.btn1.TabIndex = 50;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            // 
            // lstResults
            // 
            this.lstResults.FormattingEnabled = true;
            this.lstResults.Items.AddRange(new object[] {
            "lstResults"});
            this.lstResults.Location = new System.Drawing.Point(14, 31);
            this.lstResults.Name = "lstResults";
            this.lstResults.Size = new System.Drawing.Size(693, 160);
            this.lstResults.TabIndex = 49;
            this.lstResults.DoubleClick += new System.EventHandler(this.lstResults_DoubleClick);
            // 
            // txtEntered
            // 
            this.txtEntered.Enabled = false;
            this.txtEntered.Location = new System.Drawing.Point(14, 5);
            this.txtEntered.Name = "txtEntered";
            this.txtEntered.Size = new System.Drawing.Size(693, 20);
            this.txtEntered.TabIndex = 48;
            this.txtEntered.TextChanged += new System.EventHandler(this.txtEntered_TextChanged);
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(574, 339);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(133, 49);
            this.btnEnter.TabIndex = 47;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnShift
            // 
            this.btnShift.Location = new System.Drawing.Point(574, 282);
            this.btnShift.Name = "btnShift";
            this.btnShift.Size = new System.Drawing.Size(133, 50);
            this.btnShift.TabIndex = 46;
            this.btnShift.Text = "Shift";
            this.btnShift.UseVisualStyleBackColor = true;
            this.btnShift.Click += new System.EventHandler(this.btnShift_Click);
            // 
            // btnBackspace
            // 
            this.btnBackspace.Location = new System.Drawing.Point(574, 226);
            this.btnBackspace.Name = "btnBackspace";
            this.btnBackspace.Size = new System.Drawing.Size(133, 50);
            this.btnBackspace.TabIndex = 45;
            this.btnBackspace.Text = "<--- Backspace";
            this.btnBackspace.UseVisualStyleBackColor = true;
            this.btnBackspace.Click += new System.EventHandler(this.btnBackspace_Click);
            // 
            // btnSpace
            // 
            this.btnSpace.Location = new System.Drawing.Point(182, 364);
            this.btnSpace.Name = "btnSpace";
            this.btnSpace.Size = new System.Drawing.Size(217, 50);
            this.btnSpace.TabIndex = 44;
            this.btnSpace.Text = "Space";
            this.btnSpace.UseVisualStyleBackColor = true;
            this.btnSpace.Click += new System.EventHandler(this.btnSpace_Click);
            // 
            // btnT
            // 
            this.btnT.Location = new System.Drawing.Point(517, 308);
            this.btnT.Name = "btnT";
            this.btnT.Size = new System.Drawing.Size(50, 50);
            this.btnT.TabIndex = 43;
            this.btnT.Text = "T";
            this.btnT.UseVisualStyleBackColor = true;
            // 
            // btnS
            // 
            this.btnS.Location = new System.Drawing.Point(461, 308);
            this.btnS.Name = "btnS";
            this.btnS.Size = new System.Drawing.Size(50, 50);
            this.btnS.TabIndex = 42;
            this.btnS.Text = "S";
            this.btnS.UseVisualStyleBackColor = true;
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(405, 308);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(50, 50);
            this.btnR.TabIndex = 41;
            this.btnR.Text = "R";
            this.btnR.UseVisualStyleBackColor = true;
            // 
            // btnQ
            // 
            this.btnQ.Location = new System.Drawing.Point(349, 308);
            this.btnQ.Name = "btnQ";
            this.btnQ.Size = new System.Drawing.Size(50, 50);
            this.btnQ.TabIndex = 40;
            this.btnQ.Text = "Q";
            this.btnQ.UseVisualStyleBackColor = true;
            // 
            // btnP
            // 
            this.btnP.Location = new System.Drawing.Point(294, 308);
            this.btnP.Name = "btnP";
            this.btnP.Size = new System.Drawing.Size(50, 50);
            this.btnP.TabIndex = 39;
            this.btnP.Text = "P";
            this.btnP.UseVisualStyleBackColor = true;
            // 
            // btnO
            // 
            this.btnO.Location = new System.Drawing.Point(238, 308);
            this.btnO.Name = "btnO";
            this.btnO.Size = new System.Drawing.Size(50, 50);
            this.btnO.TabIndex = 38;
            this.btnO.Text = "O";
            this.btnO.UseVisualStyleBackColor = true;
            // 
            // btnN
            // 
            this.btnN.Location = new System.Drawing.Point(182, 308);
            this.btnN.Name = "btnN";
            this.btnN.Size = new System.Drawing.Size(50, 50);
            this.btnN.TabIndex = 37;
            this.btnN.Text = "N";
            this.btnN.UseVisualStyleBackColor = true;
            // 
            // btnM
            // 
            this.btnM.Location = new System.Drawing.Point(126, 308);
            this.btnM.Name = "btnM";
            this.btnM.Size = new System.Drawing.Size(50, 50);
            this.btnM.TabIndex = 36;
            this.btnM.Text = "M";
            this.btnM.UseVisualStyleBackColor = true;
            // 
            // btnL
            // 
            this.btnL.Location = new System.Drawing.Point(70, 308);
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(50, 50);
            this.btnL.TabIndex = 35;
            this.btnL.Text = "L";
            this.btnL.UseVisualStyleBackColor = true;
            // 
            // btnK
            // 
            this.btnK.Location = new System.Drawing.Point(14, 308);
            this.btnK.Name = "btnK";
            this.btnK.Size = new System.Drawing.Size(50, 50);
            this.btnK.TabIndex = 34;
            this.btnK.Text = "K";
            this.btnK.UseVisualStyleBackColor = true;
            // 
            // btnZ
            // 
            this.btnZ.Location = new System.Drawing.Point(517, 364);
            this.btnZ.Name = "btnZ";
            this.btnZ.Size = new System.Drawing.Size(50, 50);
            this.btnZ.TabIndex = 33;
            this.btnZ.Text = "Z";
            this.btnZ.UseVisualStyleBackColor = true;
            // 
            // btnY
            // 
            this.btnY.Location = new System.Drawing.Point(461, 364);
            this.btnY.Name = "btnY";
            this.btnY.Size = new System.Drawing.Size(50, 50);
            this.btnY.TabIndex = 32;
            this.btnY.Text = "Y";
            this.btnY.UseVisualStyleBackColor = true;
            // 
            // btnX
            // 
            this.btnX.Location = new System.Drawing.Point(405, 364);
            this.btnX.Name = "btnX";
            this.btnX.Size = new System.Drawing.Size(50, 50);
            this.btnX.TabIndex = 31;
            this.btnX.Text = "X";
            this.btnX.UseVisualStyleBackColor = true;
            // 
            // btnW
            // 
            this.btnW.Location = new System.Drawing.Point(126, 364);
            this.btnW.Name = "btnW";
            this.btnW.Size = new System.Drawing.Size(50, 50);
            this.btnW.TabIndex = 30;
            this.btnW.Text = "W";
            this.btnW.UseVisualStyleBackColor = true;
            // 
            // btnV
            // 
            this.btnV.Location = new System.Drawing.Point(70, 364);
            this.btnV.Name = "btnV";
            this.btnV.Size = new System.Drawing.Size(50, 50);
            this.btnV.TabIndex = 29;
            this.btnV.Text = "V";
            this.btnV.UseVisualStyleBackColor = true;
            // 
            // btnU
            // 
            this.btnU.Location = new System.Drawing.Point(14, 364);
            this.btnU.Name = "btnU";
            this.btnU.Size = new System.Drawing.Size(50, 50);
            this.btnU.TabIndex = 28;
            this.btnU.Text = "U";
            this.btnU.UseVisualStyleBackColor = true;
            // 
            // btnJ
            // 
            this.btnJ.Location = new System.Drawing.Point(517, 252);
            this.btnJ.Name = "btnJ";
            this.btnJ.Size = new System.Drawing.Size(50, 50);
            this.btnJ.TabIndex = 17;
            this.btnJ.Text = "J";
            this.btnJ.UseVisualStyleBackColor = true;
            // 
            // btnI
            // 
            this.btnI.Location = new System.Drawing.Point(461, 252);
            this.btnI.Name = "btnI";
            this.btnI.Size = new System.Drawing.Size(50, 50);
            this.btnI.TabIndex = 16;
            this.btnI.Text = "I";
            this.btnI.UseVisualStyleBackColor = true;
            // 
            // btnH
            // 
            this.btnH.Location = new System.Drawing.Point(405, 252);
            this.btnH.Name = "btnH";
            this.btnH.Size = new System.Drawing.Size(50, 50);
            this.btnH.TabIndex = 15;
            this.btnH.Text = "H";
            this.btnH.UseVisualStyleBackColor = true;
            // 
            // btnG
            // 
            this.btnG.Location = new System.Drawing.Point(349, 252);
            this.btnG.Name = "btnG";
            this.btnG.Size = new System.Drawing.Size(50, 50);
            this.btnG.TabIndex = 14;
            this.btnG.Text = "G";
            this.btnG.UseVisualStyleBackColor = true;
            // 
            // btnF
            // 
            this.btnF.Location = new System.Drawing.Point(294, 252);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(50, 50);
            this.btnF.TabIndex = 13;
            this.btnF.Text = "F";
            this.btnF.UseVisualStyleBackColor = true;
            // 
            // btnE
            // 
            this.btnE.Location = new System.Drawing.Point(238, 252);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(50, 50);
            this.btnE.TabIndex = 12;
            this.btnE.Text = "E";
            this.btnE.UseVisualStyleBackColor = true;
            // 
            // btnD
            // 
            this.btnD.Location = new System.Drawing.Point(182, 252);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(50, 50);
            this.btnD.TabIndex = 11;
            this.btnD.Text = "D";
            this.btnD.UseVisualStyleBackColor = true;
            // 
            // btnC
            // 
            this.btnC.Location = new System.Drawing.Point(126, 252);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(50, 50);
            this.btnC.TabIndex = 10;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            // 
            // btnB
            // 
            this.btnB.Location = new System.Drawing.Point(70, 252);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(50, 50);
            this.btnB.TabIndex = 9;
            this.btnB.Text = "B";
            this.btnB.UseVisualStyleBackColor = true;
            // 
            // btnA
            // 
            this.btnA.Location = new System.Drawing.Point(14, 252);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(50, 50);
            this.btnA.TabIndex = 8;
            this.btnA.Text = "A";
            this.btnA.UseVisualStyleBackColor = true;
            // 
            // EvNav
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(258, 253);
            this.Controls.Add(this.pnlKeyboard);
            this.Controls.Add(this.pnlHome);
            this.Name = "EvNav";
            this.Text = "EvNav";
            this.pnlHome.ResumeLayout(false);
            this.pnlHome.PerformLayout();
            this.pnlKeyboard.ResumeLayout(false);
            this.pnlKeyboard.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Button btnState;
        private System.Windows.Forms.Panel pnlHome;
        private System.Windows.Forms.Button btnCity;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Button btnStreet;
        private System.Windows.Forms.Panel pnlKeyboard;
        private System.Windows.Forms.ListBox lstResults;
        private System.Windows.Forms.TextBox txtEntered;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnShift;
        private System.Windows.Forms.Button btnBackspace;
        private System.Windows.Forms.Button btnSpace;
        private System.Windows.Forms.Button btnT;
        private System.Windows.Forms.Button btnS;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnQ;
        private System.Windows.Forms.Button btnP;
        private System.Windows.Forms.Button btnO;
        private System.Windows.Forms.Button btnN;
        private System.Windows.Forms.Button btnM;
        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.Button btnK;
        private System.Windows.Forms.Button btnZ;
        private System.Windows.Forms.Button btnY;
        private System.Windows.Forms.Button btnX;
        private System.Windows.Forms.Button btnW;
        private System.Windows.Forms.Button btnV;
        private System.Windows.Forms.Button btnU;
        private System.Windows.Forms.Button btnJ;
        private System.Windows.Forms.Button btnI;
        private System.Windows.Forms.Button btnH;
        private System.Windows.Forms.Button btnG;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnE;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.TextBox txtStreetNum;
        private System.Windows.Forms.Button btnStreetNum;
    }
}

